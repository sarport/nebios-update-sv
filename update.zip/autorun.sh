#!/usr/bin/bash

# Uncomment to run Legacy Installer
#x-terminal-emulator -e bash ./runLegacy.sh

# Uncomment to run Modern Installer
pkexec env DISPLAY=$DISPLAY XAUTHORITY=$XAUTHORITY && bash /home/$USER/.updater/runModern.sh
