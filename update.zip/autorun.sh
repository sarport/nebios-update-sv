#!/usr/bin/bash

# DO NOT DELETE ! Gui for sudo/pkexec
sudo env DISPLAY=$DISPLAY XAUTHORITY=$XAUTHORITY

# Uncomment to run Legacy Installer
x-terminal-emulator -e bash ./runLegacy.sh

# Uncomment to run Modern Installer
#pkexec bash /home/$USER/.updater/runModern.sh
