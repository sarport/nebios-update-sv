#!/usr/bin/bash

# Uncomment to run Legacy Installer
x-terminal-emulator -e bash ./runLegacy.sh

# Uncomment to run Modern Installer
#bash ./runModern.sh
