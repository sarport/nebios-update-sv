#!/usr/bin/bash

# Uncomment to run Legacy Installer
pkexec /home/$USER/.updater/run.sh "x-terminal-emulator -e bash ./runLegacy.sh"

# Uncomment to run Modern Installer
#pkexec env DISPLAY=$DISPLAY XAUTHORITY=$XAUTHORITY && bash /home/$USER/.updater/runModern.sh
