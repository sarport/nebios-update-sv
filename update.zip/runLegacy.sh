sudo apt update
sudo apt upgrade
read
