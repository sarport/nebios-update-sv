sudo -p "Enter your password: " apt update
sudo apt upgrade
read
