#!/bin/sh
(
echo "10"
echo "# Updating package list" ; sudo apt update
echo "20"
echo "# Updating Packages" ; sudo apt upgrade -y
echo "50"
echo "# Please wait..." ; sudo sh /home/$USER/.updater/other.sh
echo "75"
echo "# Rebooting system in 3 seconds..." ; sleep 3
echo "100" ; reboot

) |
zenity --progress \
  --title="Update System Logs" \
  --text="Updating System... DO NOT RESTART OR TURN OFF OR PLUG OFF YOUR COMPUTER!" \
  --percentage=0

if [ "$?" = -1 ] ; then
        zenity --error \
          --text="Update canceled."
fi 
